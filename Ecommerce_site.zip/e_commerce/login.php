<!DOCTYPE html>
<html>
<head>
<title>LOGIN PAGE</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>

.login{
	background-color:#E8E8E8;
	margin-top:80px;
	margin-left:800px;
	margin-right:500px;
	width:600px;
	text-align:center;
}

.login h1{
   text-decoration:underline;	
   text-align:center;
}

.login label{
	margin-left:20px;
	font-size:30px;
	color:red;
}

.login input{
	width:50%;
	margin:10px 0px;
	padding:15px 25px;
	cursor:pointer;
	border-style:bold;font-size:20px;
	border-radius:2px;
	
}

.login button{
	width:50%;
	font-size:30px;
	margin:0 25%;
	background-color:#4CAF50;
	color:white;height:40px;
    text-align:center;
	border:none;margin-top:20px;
}

p{
	margin-left:20px;font-size:30px
}

a{
	color:red;
	font-size:30px;
}

	
</style>

</head>
<body>
<div class="login">
<h1>Login Form</h1>
<form method="post">
<label><b>Username</b></label>
<input type="text" placeholder="Enter Username" name="name" required>
<label><b>Password</b></label>
<input type="text" placeholder="Enter Password" name="password" required>
<button type="submit" name="submit">Login</button>
</form>
<p>New Here? <a href="register.php">Register Here</a></p>
</div>
</body>
</html>


<?php 
session_start();
$conn=mysqli_connect("localhost","root","","ecommerce");
if(isset($_POST['submit']))
{
$name=mysqli_real_escape_string($conn,$_POST['name']);  //fetching username textbox text
$psw=mysqli_real_escape_string($conn,$_POST['password']);	

//query to check whether username and password is correct or not
$sql="select * from adminlogin where username='$username' and password='$password'";

//exceting the query
$res=mysqli_query($conn,$sql);
$count=mysqli_num_rows($res);

//if count>0 then username and password is correct
if($count>0)
{
	//if username and password is correct then navigating the admin to product_manage.php web page
	
$_SESSION['login']='yes';
$_SESSION['username']=$username;

header('location:product_manage.php');
die();	
}
}
else{
	echo '<script type="text/Javascript">alert("Please enter correct username and password");</script>';
	
}
	
	




?>
