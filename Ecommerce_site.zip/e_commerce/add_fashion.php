<!DOCTYPE html>
<html>
<head>
<title>Add Fashion</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
.addproduct{
	background-color:#E8E8E8;width:500px;margin-left:700px;margin-top:50px;
}

.addproduct h1{
	text-align:center;text-decoration:underline;
}

.addproduct label{
	margin-left:20px;
	font-size:20px;font-size:30px;
	color:red;
}

.addproduct input{
	width:100%;
	padding:8px 0;
	margin:8px 0;font-size:20px;
	box-sizing:border-box;
	border:1px solid #ccc;
}

.addproduct button{
    width:50%;
	margin:0 25%;
	font-size:25px;
	padding:12px 20px;
	color:white;
	border:none;margin-bottom:10px;
	background-color:#4caf50;
}


</style>

</head>

<body>
<div class="addproduct">
<h1>Add Fashion Product</h1>
<form method="post">
<label><b>Product Name</b></label>
<input type="text" placeholder="Enter Product Name" name="pname" required>

<label><b>Product Image</b></label>
<input type="file" name="pimage" required>

<label><b>Product Price</b></label>
<input type="text" placeholder="Enter Product Price" name="pprice" required>

<button type="submit" name="submit">Insert</button>
</form>
</div>
</body>
</html>

<?php  
session_start();
$conn=mysqli_connect("localhost","root","","ecommerce");

if(isset($_SESSION['login'])&&($_SESSION['login']!="")) 
{
//if insert button is clicked
if(isset($_POST['submit']))
{
$catname="fashion";

//fetching the product name,image,price data
$ppname=mysqli_real_escape_string($conn,$_POST['pname']);

$pimage=mysqli_real_escape_string($conn,$_POST['pimage']);

$pprice=mysqli_real_escape_string($conn,$_POST['pprice']);	

//insert query to insert the data into tbale named "product"
mysqli_query($conn,"insert into product(category_name,image,product_name,price) values('$catname','$pimage','$ppname','$pprice')");

echo '<script type="text/javascript">
alert("Product added sucessfully");
</script>';
header('location:product_manage.php');
die();
}
}
else
{
header('location:login.php');
die();
}
?>