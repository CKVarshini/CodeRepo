<!DOCTYPE html>
<html>
<head>
<title>Register Page</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scaled=1">
<style>
.register{
	border-radius:30px;
	background-color:#E8E8E8;
	width:700px;
	margin-top:80px;margin-left:800px;
	box-sizing:700px;
}

.register h1{
	text-align:center;
	text-decoration:underline;
}

.register label{
	color:red;
	font-size:25px;
	margin-left:20px;
}

.register input{
	width:10 0%;
	padding:12px 20px;
	box-sizing:border-box;
	margin:8px 0;
}

.register button{
	width:50%;
	margin :0 25%;
	text-align:center;
	background-color:#4caf50;
	font-size:25px;
	color:white;
	border:none;
	padding:12px 20px;margin-top:10px;
}

.register p{
	margin-left:20px;
	font-size:30px;text-align:center;
}

.register a{
	color:red;
	font-size:30px;
}



</style>
</head>
<body>

<div class="register">
<h1>Register Form</h1>
<form method="post">
<label><b>Username</b></label>
<input type="text" name="name" placeholder="Enter Username" required>

<label><b>Password</b></label>
<input type="password" name="password" placeholder="Enter Password" required>
<label><b>Confrim Password</b></label>
<input type="password" name="password" placeholder="Enter Password" required>
<button type="submit" name="submit">Register</button>
</form>
<p>Already have an account? <a href="login.php">Sign in</a></p>
</div>
</body>
</html>

<?php
$conn=mysqli_connect("localhost","root","","ecommerce"); //mysqli_connect->connect to server (servername,username,password,databasename)
//isset() ->checks whether the variable is set or not,here submit is the variable and when the button named "submit" is clicked,it will set
if(isset($_POST['submit'])){
$name=mysqli_real_escape_string($conn,$_POST['name']);  //here we are collecting data from textbox named "name" and "password" "confirmpassword"
$psw=mysqli_real_escape_string($conn,$_POST['password']);
$cpsw=mysqli_real_escape_string($conn,$_POST['confirmpassword']);
}

//we are checking password and confirmpassword matches or not
if($psw==$cpsw)
{
//writing an query to check username already exits or not 
	$sql="select * from adminlogin where username='$name'";
	
//mysqli_query()-> fuction	perform query against a database
$res=mysqli_query($conn,$sql);

//mysqli_num_rows() fuc returns number pf rows matched in the table 
$count=mysqli_num_rows($res);

//$count=0 then username is not present in table named "adminlogin"
if($count==0)
{
//query to insert user details into the table named "adminlogin"
	mysqli_query($conn,"insert into adminlogin(username,password) values('$name','$psw')");
    echo '<script type="text/Javascript">
	alert("Registration is suceccfull");
	
	window.location="login.php"; 
	</script>';
	
}
else{
	echo '<script type="text/Javascript">alert("Username already exists");</script>';
}
}
else
{
	echo'<script type="text/Javascript">alert("Password did match.Try entering the passwrod again..");</script>';
	
}

?>
