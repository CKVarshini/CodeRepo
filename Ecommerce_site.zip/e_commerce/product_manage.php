<?php 
session_start();
$conn=mysqli_connect("localhost","root","","ecommerce");
if(isset($_SESSION['login'])&&($_SESSION['login']!="")) 
{
	
}
else
{
	header('location:login.php');
	die();
}
//this loop will execute when delete button is pressed
if(isset($_GET['action'])&& $_GET['action']!='') 
{
	$type=mysqli_real_escape_string($conn,$_GET['action']);
	if($type=='delete') {
		//fetching "id" of a product to be deleted
		$id=mysqli_real_escape_string($conn,$_GET['id']);
		$delete_query="delete from product where id='$id'";
mysqli_query($conn,$delete_query);		
	}
}
?>






<!DOCTYPE html>
<html>
<head>
<title>Product Manager</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
.head{
	background-color:#00BFFF;
	padding:20px;
    text-align:center;
	font-size:40px;
	color:white;
}

.logout{
   float:right;
   color:red;
}

.category{
	background-color:lightgray;
	padding:20px;
	text-align:center;
	font-size:30px;
	color:black;
}

.add{
	float:right;
	text-decoration:none;
	color:white;
	background-color:red;
	text-align:center;
	font-size:30px;
	border:none;
	padding:5px 8px;
}

table{
	width:100%;
}

th{
	background-color:#4caf50;
	color:white;
	font-size:25px;
	padding:25px;
	text-align:center;
}

td{
	padding:25px;
	text-align:center;
	font-size:20px;
	
}

.delete{
    background-color:#f44336;
    text-decoration:none;
    font-size:25px;
    color:white;
    border:none;
    padding:5px 8px;	
}
	

</style>
</head>

<body>
<div class="head">Product Manager
<a href="logout.php" class="logout">Logout</a>
</div>

<div class="category">FASHION
<a href="add_fashion.php" class="add">Add Product</a>
</div>

<table>
<tr>
<th>Image</th>
<th>Product Name</th>
<th>Price</th>
<th>Action</th>
</tr>

<?php 
//query to fetch data from product table
$query="select * from product where category_name='fashion'";
//executing the query
$result=mysqli_query($conn,$query);
//fetching data one by one
while($row=mysqli_fetch_array($result))
{
?>	
<tr> 
<td> <img src=" <?php echo $row['image'];?>" width="100" height="100"></td>
<td><?php echo $row['product_name'];?> </td>  
<td><?php echo $row['price'];?> </td>  

<td> <?php echo ' <a herf=" ?action=delete&id='.$row["id"].' "class="delete">Delete</a> '; ?></td>
</tr>
<?php	
}
?>

</table>
<div class="category">TOYS
<a href="add_toys.php" class="add">Add Product</a>
</div>
<table>
<tr>
<th>Image</th>
<th>Product Name</th>
<th>Price</th>
<th>Action</th>
</tr>
<?php 
//query to fetch data from product table
$query="select * from product where category_name='toys'";
//executing the query
$result=mysqli_query($conn,$query);
//fetching data one by one
while($row=mysqli_fetch_array($result))
{
?>	
<tr> 
<td> <img src=" <?php echo $row['image'];?>" width="100" height="100"></td>
<td><?php echo $row['product_name'];?> </td>  
<td><?php echo $row['price'];?> </td>  

<td> <?php echo ' <a herf=" ?action=delete&id='.$row["id"].' "class="delete">Delete</a> '; ?></td>
</tr>
<?php	
}
?>
</table>
</body>
</html>