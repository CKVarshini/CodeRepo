<?php 
session_start();
//unset the session variables
unset($_SESSION['login']);
unset($_SESSION['username']);


//if logout link is clicked admin will navgate to login web page
header('location:login.php');
die();




?>