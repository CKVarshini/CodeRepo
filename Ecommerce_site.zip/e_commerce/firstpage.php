<!DOCTYPE html>
<html>
<head><title>Yashith Shop</title>
<meta name="viewport" content="width=device-width,initial-scale=1"></head>
<style>
.header{
	background-color:#00BFFF;
}
.logo{
	vertical-align:middle;
	width:60px;
	height:60px;
	
}

.header a{
	font-size:20px;
	color:#f1f1f1;
	padding:10px;
}

.nav ul{
	list-style-type:none;
	background-color:#696969;
	margin:0;
	padding:0;
	overflow:hidden;
}

.nav .categories{
	float:left;
	padding:14px 16px;
}

.nav .addtocart{
	float:right;
}

.nav .categories a{
color:white;
text-decoration:none;
}

.nav .addtocart a{
	color:red;
	background-color:white;
	padding:16px;
	margin-right:20px;
	text-decoration:none;
	font-size:20px;
}

.slideshow .image{
 width:100%;
 height:auto;
}	

.items .categoriesheading{
	background-color:#00BFFF;
	padding:0;
	margin:0;font-size:30px;
	text-align:center;
	color:white;
}

.gridcontents{
	display:grid;
	grid-template-columns:auto auto auto auto;
}

.griditems{
	text-align:center;
	margin:10px;
}

.griditems a{
	text-decoration:none;
	background-color:orange;
	font-size:25px;
	padding:5px 8px;
	
}
</style>
<body>
<!--header-->
<div class="header">
<a><img class="logo" src="logo.png">Yashith Shop</a>
</div>
<!--navigation bar-->
<div class="nav">
<ul><li class="categories"><a href="">FASHION</a></li>
    <li class="categories"><a href="">TOYS</a></li>
    <li class="categories"><a href="">ELECTRONICS</a></li>
	<li class="addtocart"><a href="">ADD TO CART</a></li>
</ul></div>
<div>
<!--slideshow-->
<div class="slideshow">
<img src="slidephoto1.png" alt="slideshow" class="image">
</div>


<!--categories-->
<div class="items">
<h1 class="categoriesheading">FASHION</h1>
<div class="gridcontents">
<div class="griditems"><img src="c1.png" width="100" height="100">
<h2>Pant</h2>
<h3>$500</h3>
<a href="">ADDTOCART</a>
</div>

<div class="griditems"><img src="c2.png" width="100" height="100">
<h2>Shirt</h2>
<h3>$400</h3>
<a href="">ADDTOCART</a>
</div>
</div>
</div>

<div class="items">
<h1 class="categoriesheading">TOYS</h1>
<div class="gridcontents">
<div class="griditems"><img src="c6.png" width="100" height="100">
<h2>Duck</h2>
<h3>$100</h3>
<a href="">ADDTOCART</a>
</div>
<div class="griditems"><img src="c7.png" width="100" height="100">
<h2>Pyramid</h2>
<h3>$200</h3>
<a href="">ADDTOCART</a>
</div>
</div>
</div>

<!--ELECTRONICS-->
<div class="items">
<h1 class="categoriesheading">ELECTRONICS</h1>
<div class="gridcontents">
<div class="griditems"><img src="c11.png" width="100" height="100">
<h2>Destop</h2>
<h3>$12000</h3>
<a href="">ADDTOCART</a>
</div>
<div class="griditems"><img src="c12.png" width="100" height="100">
<h2>Camera</h2>
<h3>$10000</h3>
<a href="">ADDTOCART</a>
</div>
</div>
</div>



</html>