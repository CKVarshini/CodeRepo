public class expression {
  public static void main(String args[]){

    //exression = operands & operators
    //operands  = value,varibale,numbers,quantity
    //operator  = + - * / %
    int friends=10;
    friends++;
    System.out.println(friends);
    friends--;
    System.out.println(friends);

    double friend=10;
    friend=(double)friend/3;
    System.out.println(friend);
  }
}
