import java.util.Scanner;

public class forloop {
  public static void main(String args[]){
    
    //for loop = excutes a block of code limited amount of times
    //3 statements= index you can declare,a condition,increment or decrement the index value by certain amount
    for(int i=10;i>=0;i--){
    System.out.println(i);
  }
   System.out.println("Happy Deepawali:)");

   for(int j=10;j>=0;j-=2){
    System.out.println(j);
   }
   System.out.println("Pew Pew!");
  }
}
