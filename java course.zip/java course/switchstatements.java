import java.util.Scanner;

public class switchstatements {
 public static void main(String args[]){
    Scanner sc=new Scanner(System.in);

    //switch = statement that allows variable to br tested for equality against a list of values
    System.out.println("Enter day name : ");
    String day=sc.nextLine();

    switch(day){
      case "Sunday":System.out.println("It is Sunday!");
      break;
      case "Monday":System.out.println("It is Monday!");
      break;
      case "Tueday":System.out.println("It is Tueday!");
      break;
      case "Wednesday":System.out.println("It is Wednesday!");
      break;
      case "Thursday":System.out.println("It is Thursday!");
      break;
      case "Friday":System.out.println("It is Friday!");
      break;
      case "Saturday":System.out.println("It is Saturday!");
      break;
      default:System.out.println("That is not a day!");
      break;
    }
}
}
