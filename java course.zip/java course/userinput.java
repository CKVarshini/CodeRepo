import java.util.Scanner;

public class userinput {
  public static void main(String args[]){
    Scanner sc=new Scanner(System.in);

    System.out.println("What is your name?");
    String name=sc.nextLine();
    
    System.out.println("What is your age?");
    int age=sc.nextInt();
    sc.nextLine();  //we use next line method of our scanner to read a line of text

    System.out.println("What is your favourite food?");
    String food=sc.nextLine();

    System.out.println("Hello " +name);
    System.out.println("Your age is " +age);
    System.out.println("Your favourite food is " +food);

  }
  
}
