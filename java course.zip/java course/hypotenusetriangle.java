import java.util.Scanner;

public class hypotenusetriangle{
  public static void main(String args[]){
   double x;
   double y;
   double z;

   Scanner sc=new Scanner(System.in);
   System.out.println("Enter the opposite side value x: ");
   x=sc.nextDouble();
   System.out.println("Enter the adjacent side value y: ");
   y=sc.nextDouble();
   
   z=Math.sqrt((x*x)+(y*y));
   System.out.println("The Hypotenuse value z is: " +z);
   sc.close();
  }

}