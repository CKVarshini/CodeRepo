public class array {
  public static void main(String args[]){
    //array[] = uaed to store mutiple values in a single variable 
    //index always start from zero
    //data types of values we are adding should be consisted with the data type of the array
    
    //String[] cars=new String[3]; 
    String[] cars={"Telsa","KIA","Skoda","Hyundai","BMW","Audi","Swift"};
    System.out.println(cars[3]);
    cars[3]="Mustang";
    System.out.println("Updated array:");
    for(int i=0;i<cars.length;i++){
      System.out.println(cars[i]);

    }
    
  }
}
