public class wrapperclass {
  public static void main(String args[]){
    
    /*wrapper class = provides a way to use primitive data types as reference data types(ex.String) 
                      reference data types =contain useful methods 
                      can be used with collections (ex.ArrayList)

      Primitive data types are more faster than reference data types              

      Primitive  -   Wrapper
      --------       -------
      1.boolean      Boolean 
      2.char         Character
      3.int          Integer
      4.double       Double
      
      autoboxing = the automatic conversion that the Java complier makes between the 
                    primitive types and thier corresponding object wrapper classes
      unboxing   = the reversr of autoboxing. Automatic conversion of wrapper class to primitive values
    */

    Boolean a = true;
    Character b = '@';
    Integer c = 123;
    Double d = 12.45;
    String e ="friend"; //as String is reference data type it starts with capital S
 
    if(a==true){ //even though a is wrapper class it behaves like primitive value because of unboxing feature
      System.out.println("This is true");
    }
    
  }
}
