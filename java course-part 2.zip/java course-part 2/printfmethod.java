// printf() = an optional method to control ,format,and display text to the console window 
//            two arguments = format string + (object/value/varibale)
//            % [flags] [precision] [width] [conversion-character]
public class printfmethod {
  public static void main(String args[]){
   System.out.printf("This is a format string %d",123);
   System.out.printf("\n%d This is a format string",123);

   boolean myBoolean = true;
   char myChar = '@';
   String myString = "Friend";
   int myInt = 12;
   double myDouble = 13476.11245;

   System.out.printf("\n%b",myBoolean);
   System.out.printf("\n%c",myChar);
   System.out.printf("\n%s",myString);
   System.out.printf("\n%d",myInt);
   System.out.printf("\n%f",myDouble);

   
   //-----[width]-----
   //   1.maximum nuber of characters to be written as output
      System.out.printf("\nHello %10s",myString);//print 10 space , -10->left justify

     
   //-----[precision]-----
  //  1.sets number of digits of precision when output the floting-point values
      System.out.printf("\nYou have this much money %.2f",myDouble);//%.2f ->we will mention how many digits to be printed after decimal place 

      
   /*-----[flags]-----
     1.add an effect to output based on the flag added to format specifier
     2. - : left-justify
     3. + : output a plus ( + ) or minus ( - ) sign fro a numeric value
     4. 0 : numeric values are zero-padded
     4. , : comma grouping seperator if numbers > 1000
   */
    System.out.printf("\nYou are good %20f",myDouble);
    System.out.printf("\nYou are good %+f",myDouble);
    double myDouble1 =  -100.100;
    System.out.printf("\nYou are good %f",myDouble1);
    System.out.printf("\nYou are good %020f",myDouble);
    System.out.printf("\nYou are good %,f",myDouble);


  }
}
