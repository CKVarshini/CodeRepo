//here we are creating method that adds two numbers and return thier sum 

public class returnmethod{
  public static void main(String args[]){
    int x = 1;
    int y= 3;
    int z = sum(x,y);//int z can be declare in main method as well as sum() method because its local variable
    System.out.println(z); 
    //System.out.println(add(x,y));
  
}

 static int sum(int x,int y){
  int z=x+y;
  return z;
  //return x+y;

 }
}

/* 
public class returnmethod{
  public static void main(String args[]){
    int x = 1;
    int y= 3;
    System.out.println(sum(x, y));
}

static int sum(int x,int y){
  return x+y;
}
}
*/