//String = A reference data type that can store one or more characters
//          reference data types have access to useful methods

public class string {
  public static void main(String args[]){
    String name ="Friend";
     boolean result = name.equals("friend");
     boolean result1= name.equalsIgnoreCase("friend");
     System.out.println(result); 
     System.out.println(result1);

     //length method
      int result2 =name.length();
      System.out.println(result2);

      //char at method 
      char result3 = name.charAt(1);
      System.out.println(result3);

      int result4 = name.indexOf("e");
      System.out.println(result4);

      //isEmpty =checks if string is empty or not
      boolean result5 = name.isEmpty();
      System.out.println(result5);

      //Uppercase to lowecase and vice versa
      String result6=name.toLowerCase();
      System.out.println(result6);

      //trim method =removes all empty spaces means white space
      String name2="   Coding";
      String result7=name2.trim();
      System.out.println(result7);

      //replace method
      String result8 = name2.replace('C', 'D');
      System.out.println(result8);

    }
}
