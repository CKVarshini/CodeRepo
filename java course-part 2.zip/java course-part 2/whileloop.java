import java.util.Scanner;

public class whileloop {
  public static void main(String args[]){
    Scanner sc=new Scanner(System.in);

    //while loop = executes block of code as long as its condition remians true
    //do while =it always execute a block of code once then checks condition
    String name = "";
    while(name.isBlank()){
     System.out.println("Enter your name: " +name);
      name=sc.nextLine();
    } 
    System.out.println("Hello " +name);
  }
}






