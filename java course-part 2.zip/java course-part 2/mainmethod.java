 //method = a block of code that is executed whenever it is called upon

 /* Simple example program :
  public class mainmethod {
   public static void main(String args[]){
    hello();
}
  static void hello(){
    System.out.println("Hello Friend!");
  }
} 
    -----OUTPUT-----:
    Hello Friend!
*/


public class mainmethod {
  public static void main(String args[]){
     String name = "Friend";
     hello(name);//we can pass in a value or a variable to the method 
     //here name is passed as argument 
 }
  
 //here hello() is the method,we can invoke this hello() method in main method
//we need to add "static" keyword ,because in main method we can't call the non-static method
  
static void hello(String name){ //here String name is passed as parameter
    System.out.println("Hello " +name);
    }
}
