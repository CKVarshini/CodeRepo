import java.util.Scanner;

public class ifstatements {
  public static void main(String args[]){
    Scanner sc=new Scanner(System.in);

    System.out.println("Enter your age : ");
    int age =sc.nextInt();
   //if statement :performs a block of code if its condition evalutes to be true 
    if (age==18)
    System.out.println("Your an adult!");
     else if(age>18)
     System.out.println("OK Boomer!");
     else if(age<18)
     System.out.println("Your a teenager!");
     else
     System.out.println(" ");

  }
}
