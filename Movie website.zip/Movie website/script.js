const homeBtn = document.getElementById('homeBtn');
const aboutBtn = document.getElementById('aboutBtn');
const loginBtn = document.getElementById('loginBtn');

const sections = document.querySelectorAll('.section');

/*homeBtn.addEventListener('click', () => {
    showSection('home');
});

aboutBtn.addEventListener('click', () => {
    showSection('about');
});

loginBtn.addEventListener('click', () => {
    showSection('login');
});

function showSection(sectionId) {
    sections.forEach(section => {
        section.style.display = 'none';
    });
    document.getElementById(sectionId).style.display = 'block';
}*/
