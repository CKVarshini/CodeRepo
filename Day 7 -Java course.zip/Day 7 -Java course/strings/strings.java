package strings;

public class strings {
  public static void main(String args[]){
    String fullName="VARSHINI";
    String name="tony";
    

  }
}
