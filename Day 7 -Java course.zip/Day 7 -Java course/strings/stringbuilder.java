package strings;

import java.util.*;

public class stringbuilder {
  public static void main(String args[]){
  StringBuilder sb=new StringBuilder("vrashini");
    System.out.println(sb);

    //charAt
    System.out.println(sb.charAt(4));

    //set charAt index
    sb.setCharAt(2, 'y');
    System.out.println(sb);
  
  //insert
  sb.insert(0,'w');
  System.out.println(sb);

  //delete
  sb.delete(2,4);
  System.out.println(sb);

  //append
  sb.append("e");
  sb.append("l");
  System.out.println(sb);
  System.out.println(sb.length());
  }
}
