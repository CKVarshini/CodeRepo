package strings;

public class stringoperatin {
  public static void main(String args[]){
    String name="varshini";
    String lastname="gowda";
    //concatenation
    String fullname=name + "@" +lastname;
    System.out.println(fullname);
    System.out.println(fullname.length());

    //charAt
    for(int i=0;i<fullname.length();i++)
    System.out.println(fullname.charAt(i));

    //compare
    //s1>s2 :+ve value
    //s1==s2 :0
    //s1<s2 :=ve value
    if(name.compareTo(lastname)==0){
      System.out.println("Strings are equal");

    }else{
      System.out.println("Not equal");
    }

    //substring(beginningindex,endingindex)
    String sentence="varshini";
    String name1=sentence.substring(0, 4);
    String name2=sentence.substring(5);
    System.out.println(name1);
    System.out.println(name2);
  }
}
