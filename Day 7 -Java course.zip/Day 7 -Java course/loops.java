import java.util.Scanner;

public class loops {

  public static void main(String args[]){
    int i=12;
    while(i<11){
      System.out.println("VARSHINI");

    }
     do{
      System.out.println("VARSHINI");
     }while(i<11);


  }
  
  
  
}
