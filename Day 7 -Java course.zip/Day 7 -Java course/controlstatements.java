import java.util.Scanner;
public class controlstatements{
  public static void main(String args[])
  {
    Scanner sc=new Scanner(System.in);
    int age=sc.nextInt();
    if(age>=18)
    {
     
      System.out.println("You're an adlut");
    }
    else
    {
      System.out.println("You're not adult");
    }
  }
}