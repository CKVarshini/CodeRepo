//JPanel = GUI component that functions as a container to hold other components

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class panel {
  public static void main(String[] args) {

    JLabel label = new JLabel();
    label.setText("Hello");
    label.setVerticalAlignment(JLabel.TOP);
    label.setHorizontalAlignment(JLabel.RIGHT);


    JPanel redpanel = new JPanel();
    redpanel.setBackground(Color.red);
    redpanel.setBounds(0,0,250,250);
    redpanel.setLayout(new BorderLayout());;

    JPanel bluepanel = new JPanel();
    bluepanel.setBackground(Color.blue);
    bluepanel.setBounds(250,0,250,250);

    JPanel greenpanel = new JPanel();
    greenpanel.setBackground(Color.green);
    greenpanel.setBounds(0,250,500,250);


    JFrame frame = new JFrame();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(750,750); 
    frame.setLayout(null);
    frame.setVisible(true);
    redpanel.add(label);//this will display text in redpanel 
    //bluepanel.add(lable);
    frame.add(redpanel);
    frame.add(bluepanel);
    frame.add(greenpanel);
  }
}
