//JLabel = a GUI display area for a string of text , an image or both

import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.border.Border;

public class jlabel {
  public static void main(String[] args) {
    JLabel label = new JLabel();//create label
    //Border border = new Border(Color.green,3); 
    //ImageIcon image = new ImageIcon("Logo.png");
     
    //lable.setIcon(image); 
    //JLabel label = new JLabel("Bro ,do you even code ");
    label.setText("Bro ,do you even code?");//set text to label 
    label.setHorizontalTextPosition(JLabel.CENTER);
    label.setVerticalTextPosition(JLabel.TOP);
    label.setForeground(new Color(0x00FF00));//set font color of text
    label.setFont(new Font("MV Boli",Font.PLAIN,20));//set font of text
    label.setIconTextGap(-25);//set gap of text to image
    label.setBackground(Color.black); // set background color
    label.setOpaque(true);//display background color
    //label.setBorder(border);
    label.setVerticalAlignment(JLabel.CENTER);//set vertical position of icon+text within label
    label.setHorizontalAlignment(JLabel.CENTER);//set horizontal position of icon+text within label
    //label.setBounds(0,0,250,250);//(x,y)=(0,0) size=(250,250) of label

    JFrame frame = new JFrame();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//exit out of application
    //frame.setResizable(false);//prevent frame fron being resized
    frame.setSize(600,600); // sets the x and y dimensional of frame
    frame.setVisible(true);//makes frame visible
    
    frame.setLayout(null);
    frame.pack();
    frame.add(label);
  }
}
