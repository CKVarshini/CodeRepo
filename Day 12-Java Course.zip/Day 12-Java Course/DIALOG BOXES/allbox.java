// JComboBox = A component that combines a button or editable field and a drop-down list 

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JFrame;

public class allbox {
  public static void main(String[] args) {
    new MyFrame();
  }
}

class MyFrame extends JFrame implements ActionListener{

  JComboBox combobox;

  MyFrame(){
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setLayout(new FlowLayout());
     
    String[] animals = {"Dog","Cat","Tiger"};
    combobox = new JComboBox(animals);
    combobox.addActionListener(this);

    combobox.setEditable(true);
    System.out.println(combobox.getItemCount());
    combobox.addItem("Horse");//this will add an item at last 
    combobox.insertItemAt("Pig", 0);
    combobox.setSelectedIndex(0);
    //combobox.removeItem("Cat");
    //combobox.removeItemAt(1);
    //combobox.removeAllItems();

    this.add(combobox);

    this.pack(); 
    this.setVisible(true);
  }
  

  @Override
  public void actionPerformed(ActionEvent e) {
    if(e.getSource()==combobox){
       System.out.println(combobox.getSelectedItem());
       System.out.println(combobox.getSelectedIndex());
    }
  }
}