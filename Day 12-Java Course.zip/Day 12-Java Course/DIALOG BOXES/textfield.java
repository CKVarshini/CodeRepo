// JTextFiels = A GUI component that can be used to add, set, or get text

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class textfield {
  public static void main(String[] args) {
    
    new myFrame();

  }
}

class myFrame extends JFrame implements ActionListener{

  JButton button;
  JTextField textfield;

  myFrame(){
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setLayout(new FlowLayout());

    button = new JButton("Submit");
    button.addActionListener(this);
   
    textfield = new JTextField();
    textfield.setPreferredSize(new Dimension(250,40));
    textfield.setFont(new Font("Consolas",Font.PLAIN,35));
    textfield.setForeground(new Color(0x00FF00));
    textfield.setBackground(Color.black);
    textfield.setCaretColor(Color.white);
    textfield.setText("User name");

    this.add(button);
    this.add(textfield);
    this.pack();//we will pack this frame, so that the frame will adjust the size to components we add to frame 
    this.setVisible(true);

  }

  @Override
  public void actionPerformed(ActionEvent e) {
   if(e.getSource()==button){
    System.out.println("Welcome " +textfield.getText());
    button.setEnabled(false);
    textfield.setEditable(false);
    }
  }
}
