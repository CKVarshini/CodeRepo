// JCheckBox = A GUI component that can be selected or deselected

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;

public class checkbox {
  public static void main(String[] args) {
   
    new MyFrame();

  }
}

class MyFrame extends JFrame implements ActionListener{
  
   JButton button;
   JCheckBox checkBox;

  MyFrame(){
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setLayout(new FlowLayout());
    
    button = new JButton();
    button.setText("Submit");
    button.addActionListener(this);

    checkBox = new JCheckBox();
    checkBox.setText("I'm mot a robot");
    checkBox.setFocusable(false);//removes border around text->"I'm mot a robot"
    checkBox.setFont(new Font("Consolas",Font.PLAIN,25));

    this.add(button);
    this.add(checkBox);
    this.pack();//we will pack this frame, so that the frame will adjust the size to components we add to frame 
    this.setVisible(true);
}

  @Override
  public void actionPerformed(ActionEvent e) {
    if(e.getSource()==button){
     System.out.println(checkBox.isSelected());
    }
  }
  
}

/* To change the apperance of checkbox
  ImageIcon xIcon;
  ImageIcon checkIcon;

  xIcon = new ImageIcon("x.png");
  checkIcon = new ImageIcon(check.png);

  checkbox.setIcon(xIcon);
  checkbox.setSelectedIcon(checkIcon);
 */
