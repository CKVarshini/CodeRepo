import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class optiondialog {
  public static void main(String[] args) {
     
    String[] responses = {"No.you're awesome!","thank you","blush:)"};
    //ImageIcon image = new ImageIcon("smile.png");
  
    JOptionPane.showOptionDialog(null, "You are awesome", 
    "secret message", 
    JOptionPane.YES_NO_CANCEL_OPTION, 
    JOptionPane.INFORMATION_MESSAGE,
     null, //here we can set our own icon
     responses, 
     0);
  }
}
