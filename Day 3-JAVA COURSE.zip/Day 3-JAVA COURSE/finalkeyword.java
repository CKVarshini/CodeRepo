public class finalkeyword{
public static void main(String[] args) {
  final double pi = 3.14159;
  System.out.println(pi);
 }
}