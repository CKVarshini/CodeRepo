// object = an instance of class that may contain attributes and methods
// example : (phone,car,computer,coffee cup)

/* consider coffee cup as object :
    Attributes :
                 String color = "white"; 
                 double temp = 20.0;
                 boolean empty = false;

    Methods (actions) :
                        drink() {
                          System.out.println("You drink coffee");
                        }
                        spill(){
                           System.out.println("You spill the coffee :(");
                        }  
                 
 */ 

 public class object {
  public static void main(String[] args) {
     Car myCar1 = new Car();
     Car myCar2 = new Car();

     System.out.println(myCar1.model);
     System.out.println(myCar1.color);
 
     System.out.println(myCar2.model);
     System.out.println(myCar2.color);


     myCar1.drive();
     myCar1.brake();

     myCar2.drive();
     myCar2.brake();
  }
}

//now considering car as object
 class Car{
  //Attributes 
  String make = "Chevrolet";
  String model = "Corvette";
  int year = 2020;
  String color = "Red";
  double price = 50000.000;

  //Methods
  void drive(){
    System.out.println("You drive the car");
  }

  void brake(){
    System.out.println("You step on the brakes");
  }
}




