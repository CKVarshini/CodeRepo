
public class constructor {
  public static void main(String[] args) {
    Human human1 = new Human("Jhon",4,12.44);
    Human human2 = new Human("Richard",65,56.44);

    System.out.println(human1);
    System.out.println(human2);

    human2.eat();
    human1.drink();
    
  }
}
// constructor = special method that is called when an object is instantiated(created)
 class Human {
   String name;
   int age;
   double weight;
   
  //we can pass parameters to constructor
  Human(String name,int age,double weight){
       this.name = name;
       this.age = age;
       this.weight = weight;
 }
  
  void eat(){
    System.out.println(this.name+ " is eating");
  }

  void drink(){
    System.out.println(this.name+ " drinks milk and he is " +this.age+ " years old");
  }

}

