import java.io.FileWriter;
import java.io.IOException;

public class main {
  public static void main(String[] args) {

    try{
    FileWriter writer = new FileWriter("poem.txt");
    writer.write("Roses are red\n Violets are blue\nRockin' eveywhere!!!");
    writer.append("\n A poem by your FRIEND");
    writer.close();
    }

    catch(Exception e){
      e.printStackTrace();
    }

  }
  
}
