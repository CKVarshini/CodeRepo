// Polymorphism = greek word fro poly-"many" , morph -"from"
//                The ability of an object to identify as more than one type(here car can be identified as vechile,object and as car too)

package polymorphism;

public class Polymorphism{
  public static void main(String[] args) {

    Car car = new Car();
    Bicycle  bicycle = new Bicycle();
    Boat boat = new Boat();

    Vehicle[] racers = {car,bicycle,boat};//we will all the objects in an array
    
    //car.go();
    //bicycle.go();

    for(Vehicle x : racers){ // x is counter it represents all object in an array
      x.go();
    }
}
}

class Vehicle {
  public void go(){
    
  }
}

class Car extends Vehicle {
  @Override
  public void go(){
    System.out.println("The car begins to move");
  }
  
}

class Bicycle extends Vehicle {
  @Override
  public void go(){
    System.out.println("The bicycle begins to move");
  }
}

class Boat extends Vehicle {
  @Override
  public void go(){
    System.out.println("The boat begins to move");
  }
}


