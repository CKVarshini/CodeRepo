/*
  EXCEPTION =an event oocurs during the execution of a program that ,
              distrubs the normal flow of instructions

              try-catch block
*/

import java.util.*;
public class exceptions {
  public static void main(String[] args) {
   Scanner sc= new Scanner(System.in);
  
  try{
    System.out.println("Enter a whole number to divide: ");
    int x= sc.nextInt();

    System.out.println("Enter a whole number to divide by: ");
    int y= sc.nextInt();

    float z= x/y;
    System.out.println("RESULT : "+z);
   }

   catch(ArithmeticException e){
    System.out.println("You can't divide by ZERO!!!");
   }

   catch(InputMismatchException e){
    System.out.println("Please enter a number");
   }

   catch(Exception e){
    //Exception e = This will catch all kinds of expections 
    System.out.println("Something went wrong!!!!");
   }

   finally{
    sc.close();
   }
   
 }
}
