/*
    INTERFACE = a template that can applied to a class.
                similar to INHERITANCE, but specifies what class has/must do.
                classes can apply more than one interface ,inheritance is limites to 1 super class 
  */

public class interfacemain {
  public static void main(String[] args) {
   Rabit rabit = new Rabit();
   rabit.flee();

   Hawk hwak = new Hawk();
   hwak.hunt();

   Fish fish = new Fish();
   fish.hunt();
   fish.flee();
  }
}

interface Pery{
   void flee();

}

interface Predator{
  void hunt();
}

class Rabit implements Pery{
   @Override
   public void flee(){
      System.out.println("The rabit is fleeing");
   }
}

class Hawk implements Predator{
  @Override
  public void hunt(){
    System.out.println("The hwak is hunting");
  }


} 

class Fish implements Pery,Predator{
  @Override
  public void hunt(){
    System.out.println("The fish is hunting");
  }

  public void flee(){
    System.out.println("The fish is fleeing");
  }
}



