// JButton = a button that perform an action when clicked on

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class button {
  public static void main(String[] args) {
   
    myFrame myframe = new myFrame();
  }
}

class myFrame extends JFrame {
  JButton button;
  myFrame(){

    button = new JButton();
    button.setBounds(200,100,250,500);
    button.addActionListener(e -> System.out.println("Hi"));
    button.setText("I'm a button");
    button.setFocusable(false);


    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//exit out of application
    //this.setResizable(false);prevent frame fron being resized
    this.setSize(500,500); // sets the x and y dimensional of frame
    
    this.add(button);
    this.setVisible(true);//makes frame visible
  }

 /*  @Override
  public void actionPerformed(ActionEvent e){
    if(e.getSource()==button){


      
    }*/

  }



