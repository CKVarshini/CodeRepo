//Here "JOptionPane"  method is used to display message dialog box"

import javax.swing.JOptionPane;

public class GUI {
 public static void main(String args[]){ 
  String name = JOptionPane.showInputDialog("Enter your name ");
  JOptionPane.showMessageDialog(null, "Hello " +name);
  
  /* 1.Integer = wrapper class
     2.JOptionPane will return a string based on what user types
     3.parseInt method will convert it to an interger that we can store it within interger
     variable of age*/
  int age = Integer.parseInt(JOptionPane.showInputDialog("Enter your age"));
  JOptionPane.showMessageDialog(null,"Your age is " +age);

  double height = Double.parseDouble(JOptionPane.showInputDialog("Enter your height"));
  JOptionPane.showMessageDialog(null,"Your are "+height+ "cm tall");


 }
}
 
  

