// Jframe = a GUI window to add components to

import javax.swing.JFrame;
import javax.swing.JFrame;
import java.awt.Color;

public class jframes {
  public static void main(String[] args) {
    JFrame frame = new JFrame(); //creates frame
    //myframe Myframe = new myframe();

    frame.setTitle("Jframe title goes here"); //sets title of frame
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//exit out of application
    frame.setResizable(false);//prevent frame fron being resized
    frame.setSize(420,420); // sets the x and y dimensional of frame
    frame.setVisible(true);//makes frame visible
    frame.getContentPane().setBackground(new Color(0,0,0));
    //frame.getContentPane().setBackground(new Color(0xFFFFFF));
    
    //to set logo at top left corner of Jframe
    //import javax.swing.ImageIcon
    //ImageIcon image = new ImageIcon("Logo.png");
    //frame.setImageIcon(image.getImage());
  }
}

class myframe extends JFrame{
  myframe(){
    this.setTitle("Jframe title goes here"); //sets title of frame
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//exit out of application
    this.setResizable(false);//prevent frame fron being resized
    this.setSize(420,420); // sets the x and y dimensional of frame
    this.setVisible(true);//makes frame visible
    this.getContentPane().setBackground(new Color(0,0,0));

    
  }
}



