import java.util.Scanner;

import javax.sound.sampled.SourceDataLine;

public class logicaloperators {
  public static void main(String args[]){
    Scanner sc=new Scanner(System.in);
    /*logical operator = used to connect the two or more expressions
     1.&& = AND => both coditions must be true
     2.|| = OR  =>either conditions must be true
     3.!  = NOT =>reverse boolean value of condition
     */

     System.out.println("Enter the temperatute value : ");
     int temp=sc.nextInt();
     
     if (temp>30){
     System.out.println("It is hot outside");
     }
     else if(temp>=20 && temp<=30){
     System.out.println("It is warm outside");
     }
     else if(temp<20 || temp<15){
      System.out.println("It is cold outside");
     }
     
    
  //logical OR 
  Scanner scanner=new Scanner(System.in);
   System.out.println("You are reading book! Press r or R to quit");
   String response=scanner.nextLine();

   if(response.equals('r') || response.equals('R'))
   {
    System.out.println("You qiut reading book");
   }
   else
   {
    System.out.println("You are still reading book ");
  }
  
  //NOT logical operator
  Scanner scanner2=new Scanner(System.in);
   System.out.println("You are reading book! Press r or R to quit");
   String response1=scanner2.nextLine();

   if(!response1.equals('r') && !response1.equals('R'))
   {
    System.out.println("You qiut reading book");
   }
   else
   {
    System.out.println("You are still reading book ");
  }
}
}