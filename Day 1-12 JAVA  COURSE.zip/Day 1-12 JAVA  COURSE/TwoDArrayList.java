import java.util.*;
public class TwoDArrayList {
  public static void main(String args[]){
    //2D ArrayList = A dynamic list of lists
    //can change the size of these lists during runtime 
    
    ArrayList<ArrayList<String>> groceryList=new ArrayList();


     ArrayList<String> bakeryList= new ArrayList();
     bakeryList.add("Pasta");
     bakeryList.add("Garlic bread");
     bakeryList.add("Dounts");

     ArrayList<String> produceList = new ArrayList();
     produceList.add("Tomatoes");
     produceList.add("Pepper");
     produceList.add("Potato");
       
     ArrayList<String> drinkList = new ArrayList();
     drinkList.add("Soda");
     drinkList.add("Lemon Juice"); 

     groceryList.add(bakeryList);
     groceryList.add(produceList);
     groceryList.add(drinkList);
     
     System.out.println(groceryList);
     System.out.println(groceryList.get(1));
     System.out.println(groceryList.get(1).get(1));//to retrieve the particulat value from array list
    
   
  }
}
