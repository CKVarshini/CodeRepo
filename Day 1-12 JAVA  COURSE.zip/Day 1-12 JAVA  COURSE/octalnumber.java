public class octalnumber{
  public static void main(String[] args){
 int x[]={120,200,016};
 for(int i=0;i<x.length;i++){
  System.out.println(x[i]);
  } 
 }
}

//OUTPUT : 120 200 14 
//016 is octal number ->any number starts with zero ,so it is consider as octal

/*
  public class octalnumber{
   public static void main(String[] args) {
   int x[]={120,200,006};
   for(int i=0;i<x.length;i++){
    System.out.println(x[i]);
  } 
 }
}

OUTPUT :
         120 200 6 
*/