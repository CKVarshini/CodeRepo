package arrays;

public class arrays {
  public static void main(String args[]){
    int[] marks=new int[3];
    marks[0]=97;
    marks[1]=76;
    marks[2]=65;
    //System.out.println(marks[1]);
    //System.out.println(marks[2]);
    for(int i=0;i<3;i++){
    System.out.println(marks[i]);
  }

int mark[]={97,76,65};
for(int j=0;j<3;j++)
System.out.println(mark[j]);

}
  
}

