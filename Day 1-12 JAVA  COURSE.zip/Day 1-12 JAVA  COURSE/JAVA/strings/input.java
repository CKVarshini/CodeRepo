package strings;

import java.util.*;

import javax.print.DocFlavor.STRING;

public class input {
  public static void main(String args[]){
    Scanner sc=new Scanner(System.in);
    String name=sc.next();
    System.out.println("Your name is : " +name);

  }
}
