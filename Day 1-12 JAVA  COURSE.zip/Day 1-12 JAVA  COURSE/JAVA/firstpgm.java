import java.util.*;

public class firstpgm {
  public static void main(String args[])
  {
    Scanner sc=new Scanner(System.in);
    int n=sc.nextInt();

    int sum=0;int i;
    for(i=0;i<=n;i++)
    {
     sum=sum+i;
    }
    System.out.println(sum);
  }
  
}
