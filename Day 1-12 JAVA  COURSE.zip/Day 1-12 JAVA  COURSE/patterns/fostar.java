package patterns;

public class fostar 
{
  public static void main(String args[])
  {
    int n=4;
    int i,j;
    for(i=n;i>=1;i--)
    {
      for(j=1;j<=i;j++)
      {
        System.out.print("*");
      }
    System.out.println();
    } 
  }


}
