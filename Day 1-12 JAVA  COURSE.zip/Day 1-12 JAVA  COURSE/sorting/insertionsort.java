package sorting;

public class insertionsort {
  public static void printArray(int array[]){
    for(int i=0;i<array.length;i++){
    System.out.print(array[i]+ " ");
  }
  System.out.println();
}

  public static void main(String args[]){
    int array[]={7,4,10,8,3,1};
    for(int i=1;i<array.length;i++){
      int current=array[i];
      

      




    }


}
}
