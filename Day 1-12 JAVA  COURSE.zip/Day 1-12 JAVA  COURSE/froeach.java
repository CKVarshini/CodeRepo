import java.util.ArrayList;

public class froeach {
  public static void main(String args[]){
    //fro-each loop = traversing technique to iterate through the elements in a array/collection
    //                less steps,more readable
    //                less fexible 
     
    String[] animals = {"Tiger","Cat","Dog","Rat"};
    // : ->represents the word in i.e for every string index in array of animals 
    for(String i : animals){
      System.out.println(i); 
    }
  
  //for-each loop using collection 
     ArrayList<String> animals1 = new ArrayList();
     
     animals1.add("Bird");
     animals1.add("Lion");
     animals1.add("Wolf");
     System.out.println("The output of array list animals1 using colection : ");
     for(String i : animals1){
       System.out.println(i);
     }
    }
}
 
