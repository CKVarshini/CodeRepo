import java.util.ArrayList;

public class arraylist {
  public static void main(String args[]){
    /* ArrayList = -a resizable array.<>written within angular brackets
                   -Element can be added and removed after compilation phase
                   -store reference data types
     */
    //if we need to store primitive values like double,integer,character then we should use wrapper class
    //Ex: to store interger within arraylist we will not use int rather we will use Integer
     //ArrayList<Integer>, ArrayList<Charcter>

     ArrayList<String> food = new ArrayList<String>();
     //to add items to an arraylist use add method 
     food.add("Pizza");
     food.add("Burger");
     food.add("Fries");
    
     //in arraylist we use .size()
     for(int i=0;i<food.size();i++){
      System.out.println(food.get(i));

      food.set(1,"Panner");//to set value at particular index
      food.remove(2);//to remove itam from arraylist
      food.clear();//to clear the arraylist
     }
  }
}
