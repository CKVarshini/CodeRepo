public class Car {
  String make = "Chevrolet";
  String model = "Corvette";
  int year = 2020;
  String color = "Red";
  
   public String toString(){
    return make +"\n" +model+ "\n" +year+ "\n" +color;
  }
}
  

