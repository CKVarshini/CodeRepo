/* toString() = special method that all objects inherit ,
                that returns a string that "textually represents" an object.
                can be used bth implicity and ecplicity   
 */
public class tostringmethod {
  public static void main(String[] args) {
    Car myCar1 = new Car();

    System.out.println(myCar1.toString()); // toString() -> returns memory address of where car object is in memory
    System.out.println(myCar1);
  }
}

