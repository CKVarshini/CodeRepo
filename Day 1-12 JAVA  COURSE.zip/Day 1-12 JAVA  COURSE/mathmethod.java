public class mathmethod {
  public static void main(String args[]){
    double x=10.8;
    double y=-3.999;

    double z=Math.max(x,y);
    System.out.println("The maximun value bewtween x and y is : " +z);

    //absolute function returns a number without a negative sign
    double c=Math.abs(y);
    System.out.println("The absolute value of y is: " +c);

    double d=Math.sqrt(x);
    System.out.println("The squared value of x is :"+d);
  }
  
}
