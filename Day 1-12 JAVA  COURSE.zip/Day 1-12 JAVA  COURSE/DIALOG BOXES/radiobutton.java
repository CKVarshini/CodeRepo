// JRadioButton = One or more buttons in a grouping in which only 1 may be selected per group 

import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.System;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JRadioButton;

public class radiobutton {
  public static void main(String[] args) {
    new MyFrame();
  }
}

class MyFrame extends JFrame implements ActionListener{
  
  JButton button;
  JRadioButton pizzaButton,hamburgerButton,hotdogButton;
  //ImageIcon pizzaIcon,hamburgerIcon,hotdogIcon;
 
  MyFrame(){

    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setLayout(new FlowLayout());

    /*
    pizzaIcon = new ImageIcon("pizza.png");
    hamburgerIcon = new ImageIcon("hamburger.png");
    hotdogIcon = new ImageIcon("hotdog.png");
    */
    pizzaButton = new JRadioButton("Pizza");
    //pizzaButton.setText("Pizza");
    hamburgerButton = new JRadioButton("Hamburger");
    hotdogButton = new JRadioButton("Hotdog");

    ButtonGroup group = new ButtonGroup();
    group.add(pizzaButton);
    group.add(hamburgerButton);
    group.add(hotdogButton);

    pizzaButton.addActionListener(this);
    hamburgerButton.addActionListener(this);
    hotdogButton.addActionListener(this);

    /* pizzaButton.setIcon(pizzaIcon);
    hamburgerButton.setIcon(hamburgerIcon);
    hotdogButton.setIcon(hotdogIcon);
    */

    this.add(pizzaButton);
    this.add(hamburgerButton);
    this.add(hotdogButton);
    this.pack();//we will pack this frame, so that the frame will adjust the size to components we add to frame 
    this.setVisible(true);
  }

  @Override
  public void actionPerformed(ActionEvent e) {
    if(e.getSource()==pizzaButton){
    System.out.println("You ordered Pizza:)");
  }
  else if(e.getSource()==hamburgerButton){
   System.out.println("You ordered a Hamburger:)");
  }

  else if(e.getSource()==hotdogButton){
   System.out.println("You ordered a HotDog:)");
  }
 }
}