import javax.swing.JOptionPane;

public class confirmdialogbox {
  public static void main(String[] args) {

    //JOptionPane.showConfirmDialog(null,"Bro do you even code?","This is my title",JOptionPane.YES_NO_CANCEL_OPTION));
    System.out.println(JOptionPane.showConfirmDialog(null,"Bro do you even code?","This is my title",JOptionPane.YES_NO_CANCEL_OPTION));
    //the print line statement returns 0- for yes.1-for no.2-for cancel
 
    //we can store in variable too
    //int answer = JOptionPane.showConfirmDialog(null,"Bro do you even code?","This is my title",JOptionPane.YES_NO_CANCEL_OPTION));
  }
  }

