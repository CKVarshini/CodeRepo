
/*
   JOptionPane = Pop up a standard dialog box that prompts users for a value 
                 or informs them of something 
 */

import javax.swing.JOptionPane;

public class dialogbox{
  public static void main(String[] args) {
    //JOptionPane.showMessageDialog(null, "This is some useless info", "title",JOptionPane.PLAIN_MESSAGE);
    //JOptionPane.showMessageDialog(null, "This is more useless info : D", "title",JOptionPane.INFORMATION_MESSAGE);
    //JOptionPane.showMessageDialog(null, "really", "title",JOptionPane.QUESTION_MESSAGE);
     
    JOptionPane.showMessageDialog(null, "You're computer has a virus!!!", "title",JOptionPane.WARNING_MESSAGE);
    
    /*while(true){
    JOptionPane.showMessageDialog(null, "You're computer has a virus!!!", "title",JOptionPane.WARNING_MESSAGE);
    }
    */

    
  }
}
 
