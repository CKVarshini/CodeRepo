/*
   Overloded constructor = multiple constructor within a class with the same name,
                           but have diiferent parameters 
                           name +parameter = signature
 */

public class overloadedconstructor {
  public static void main(String[] args) {
    //Pizza pizza = new Pizza();->we can create constructor with no arguments too ,written Pizza() in line no.33
    Pizza pizza1 = new Pizza("thicc crust","Tomoto","mozzerella","pepperoni");
    Pizza pizza2 = new Pizza("thicc crust","Tomoto","mozzerella");
    System.out.println("Here are the ingredients of your pizza : ");
    System.out.println(pizza1.bread);
    System.out.println(pizza1.sos);
    System.out.println(pizza1.cheese);
    System.out.println(pizza1.topping);

    System.out.println("Here are the ingredients of your pizza : ");
    System.out.println(pizza2.bread);
    System.out.println(pizza2.sos);
    System.out.println(pizza2.cheese);


  }
  
}

class Pizza{
  String bread;
  String sos;
  String cheese;
  String topping;
 //Pizza();
  Pizza(String bread,String sos,String cheese,String topping){
    this.bread =  bread;
    this.sos = sos;
    this.cheese = cheese;
    this.topping = topping;
  }

  Pizza(String bread,String sos,String cheese){ //constructor with only 3 paramets
    this.bread =  bread;
    this.sos = sos;
    this.cheese = cheese;
  }

  Pizza(String bread,String cheese){
    this.bread =  bread;
    this.cheese = cheese;
  }

   Pizza(String bread){ //constructor with only 1 parameter
    this.bread =  bread;
  }  

}

