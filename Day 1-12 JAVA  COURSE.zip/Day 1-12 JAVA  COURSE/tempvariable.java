public class tempvariable {
  public static void main(String args[]){
    int x=10;
    int y=20;
    int temp;
     temp=x;
     x=y;
     y=temp;
      System.out.println("x:" +x);
      System.out.println("y:" +y);
      System.out.println("temp:" +temp);

      /*
      Swapping two variables without using third variable 
      x=1 , y=2
      x=x+y;=>x=1+2=3
      y=x-y;=>y=3-2=1
      x=x-y;=>x=3-1=2
      System.out.println("x: " +x);
      System.out.println("y: " +y);
      
      output: x:2 , y:1 */

     
      /*Swapping three variables without using fourth variable 
      x=1,y=2,z=3
      x=x+y+z;=>x=1+2+3=6
      y=x-y+z;=>y=6-2+3=1
      z=x-y+z;=>z=6-1+3=2
      x=x-y+z;=>x=6-1+2=3
      System.out.println("x: " +x);
      System.out.println("y: " +y);
      System.out.println("x: " +z);
      
      output: x:3 , y:1 , z=2*/
  }
  
}
