//mainmethod part 2
public class method {
  public static void main(String args[]){
    String name = "Friend";
    int age = 21;

    hello(name,age);
  }
//we should pass maching set of parameters and arguments i.e we should pass both name and age parameters in hello() method
  static void hello(String name,int age){
    System.out.println("Hello " +name+ ".You are "+age+ " years old");
  }
}
