public class variables {
  public static void main(String args[]){
    int x=123;
    float y=23.3f;
    double c=34.55;
    boolean z=true;
    char symbol='@';
    String name="friend";

    System.out.println(x);
    System.out.println("my number is : " +x);
    System.out.println("my name is" +name);
  }
}
