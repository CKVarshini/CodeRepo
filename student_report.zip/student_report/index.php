<?php
include("connection.php");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Teacher Login Page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }
        
        .login-container {
            background-color: #ffffff;
            width: 400px;
            margin: 100px auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        
        .login-title {
            font-size: 24px;
            margin-bottom: 20px;
            color: #333333;
        }
        
        .login-label {
            display: block;
            font-size: 18px;
            margin-bottom: 10px;
            color: #555555;
            text-align: left;
						margin-top:3px;
        }
        
        .login-input {
            width: 60%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }
        
        .login-button {
            width: 40%;
            padding: 12px;
			margin-top:7px;
            background-color:#03AC13;
            border: none;
            color: white;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .login-button:hover {
            background-color: darkgreen;
        }
        
        .login-info {
            margin-top: 20px;
            font-size: 16px;
        }
        
        .login-info a {
            color: #e74c3c;
            text-decoration: none;
        }

				@media screen and (max-width: 480px) {
            .login-container {
                width: 90%;
            }
					
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h1 class="login-title">Teacher's Login Form</h1>
        <form action="login.php" method="post">
            <label class="login-label">Username</label>
            <input type="text" class="login-input" placeholder="Enter Username" name="user" required>
            <label class="login-label">Password</label>
            <input type="password" class="login-input" placeholder="Enter Password" name="password" required>
            <button type="submit" class="login-button" name="submit">Login</button>
            <button type="reset" class="login-button" name="reset">Reset</button>
        </form>
        
    </div>
</body>
</html>



