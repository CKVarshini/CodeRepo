<?php
$conn = mysqli_connect("localhost", "root", "", "student_report");
if (isset($_POST['insert'])) {
    $student_usn = mysqli_real_escape_string($conn, $_POST['student_usn']);
    $student_name = mysqli_real_escape_string($conn, $_POST['student_name']);
    $subject1 = mysqli_real_escape_string($conn, $_POST['subject1']);
    $subject2 = mysqli_real_escape_string($conn, $_POST['subject2']);
    $subject3 = mysqli_real_escape_string($conn, $_POST['subject3']);
    $subject4 = mysqli_real_escape_string($conn, $_POST['subject4']);
    $subject5 = mysqli_real_escape_string($conn, $_POST['subject5']);
    
  
    $totalMarks = $subject1 + $subject2 + $subject3 + $subject4 + $subject5;

    
    $query = "INSERT INTO marks(student_usn, student_name, subject1, subject2, subject3, subject4, subject5, totalmarks) 
              VALUES ('$student_usn', '$student_name', '$subject1', '$subject2', '$subject3', '$subject4', '$subject5', '$totalMarks')";
    
    $data = mysqli_query($conn, $query);
    if ($data) {
        echo "<script type='text/javascript'>
              alert('Data inserted successfully');
              </script>";
    } else {
        echo "Failed";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
    body {
        font-family: Arial, sans-serif;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        margin: 0;
        background-color: #f2f2f2;
    }
    .container {
        width: 400px;
        padding: 20px;
        background-color: white;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    h1 {
        text-align: center;
        margin-bottom: 20px;
    }
    label, input {
        display: block;
        margin-bottom: 10px;
    }
    input[type="text"], input[type="number"] {
        width: 96%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 3px;
    }
    button {
        width: 100%;
        padding: 10px;
        background-color: #3498db;
        border: none;
        color: white;
        border-radius: 3px;
        cursor: pointer;
    }
    button:hover {
        background-color: #2980b9;
    }
</style>
<title>Enter Student Marks</title>
<script>
    function calculateTotal() {
        const subject1 = parseFloat(document.getElementById('subject1').value) || 0;
        const subject2 = parseFloat(document.getElementById('subject2').value) || 0;
        const subject3 = parseFloat(document.getElementById('subject3').value) || 0;
        const subject4 = parseFloat(document.getElementById('subject4').value) || 0;
        const subject5 = parseFloat(document.getElementById('subject5').value) || 0;

        const totalMarks = subject1 + subject2 + subject3 + subject4 + subject5;
        document.getElementById('totalMarks').textContent = `Total Marks: ${totalMarks}`;
    }
</script>
</head>
<body>
    <div class="container">
        <h1>Enter Student Marks</h1>
        <form method="post">
            <label for="usn">Student USN:</label>
            <input type="text" id="usn" name="student_usn" required>
            
            <label for="name">Student Name:</label>
            <input type="text" id="name" name="student_name" required>
            
            <label for="subject1">Subject 1 Marks:</label>
            <input type="number" id="subject1" name="subject1" min="0" max="100" required>
            
            <label for="subject2">Subject 2 Marks:</label>
            <input type="number" id="subject2" name="subject2" min="0" max="100" required>
            
            <label for="subject3">Subject 3 Marks:</label>
            <input type="number" id="subject3" name="subject3" min="0" max="100" required>
            
            <label for="subject4">Subject 4 Marks:</label>
            <input type="number" id="subject4" name="subject4" min="0" max="100" required>
            
            <label for="subject5">Subject 5 Marks:</label>
            <input type="number" id="subject5" name="subject5" min="0" max="100" required>
            
            <button type="button" onclick="calculateTotal()">Calculate Total</button>
            <p id="totalMarks"></p>
            
          <button type="submit" name="insert"> INSERT</button>
        </form>
    </div>
</body>
</html>
