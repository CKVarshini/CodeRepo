<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Login</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f2f2f2;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}

.login-container {
    background-color: #ffffff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    width: 300px;
    text-align: center;
}

h1 {
    color: black;
    margin-bottom: 20px;
}

label {
    display: block;
    margin-bottom: 10px;
    font-weight: bold;
}

input[type="text"] {
    width: 60%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

button {
    padding: 10px 20px;
    background-color: #03AC13;
    border: none;
    color: white;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s;
    margin-top:7px;
}

button:hover {
    background-color: darkgreen;
}

@media screen and (max-width: 480px) {
    .login-container {
        width: 100%;
        border-radius: 0;
    }
}

    </style>
</head>
<body>
    <div class="login-container">
        <h1>Student Login</h1>
        <form action="retrieve_data.php" method="post">
            <label for="usn">Enter your USN:</label>
            <input type="text" id="usn" name="usn" required>
            <br>
            <button type="submit" name="login">Login</button>
            <button type="reser" name="reser">Reset</button>
        </form>
        <p>Are you a teacher?Login Here!</p>
        <a class="teacher-button" href="index.php">Teacher Login</a>
    </div>
</body>
</html>
