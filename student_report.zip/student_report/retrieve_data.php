<?php
$conn = mysqli_connect("localhost", "root", "", "student_report");

if (isset($_POST['login'])) {
    $usn = mysqli_real_escape_string($conn, $_POST['usn']);
    
    $query = "SELECT * FROM marks WHERE student_usn = '$usn'";
    $result = mysqli_query($conn, $query);
    
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
       
        echo "<h1>
        
        Student Name:{$row['student_name']}</h1>";
        echo "<p><h2>Student USN: {$row['student_usn']}</h2></p>";
        echo "<p>Subject 1 Marks: {$row['subject1']}</p>";
        echo "<p>Subject 2 Marks: {$row['subject2']}</p>";
        echo "<p>Subject 3 Marks: {$row['subject3']}</p>";
        echo "<p>Subject 4 Marks: {$row['subject4']}</p>";
        echo "<p>Subject 5 Marks: {$row['subject5']}</p>";
        echo "<p><h3>Total Marks: {$row['totalMarks']}</h3></p>";
    } else {
        echo "<h1>Student USN not found.</h1>";
    }
}

mysqli_close($conn);
?>
<!DOCTYPE html>
<html>
<head>
    <style>
        h1,h2,h3,p{
            text-align:center;
        }